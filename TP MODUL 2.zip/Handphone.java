public class Handphone {
    public void informasi()
{
    System.out.println("Handphone ini memiliki drive tipe sandisk dengan ram sebesar 3 GB dan processor secepat 2.20 Ghz. Selain itu handphone ini TIDAK memiliki Fingerprint");
}
    public void telfon(int no_hp)
    {
        System.out.println("Handphobe berhasil menyambungkan telfon ke No 080812213443");

    }
    public void kirimSMS(int no_hp)
    {
        System.out.println("Handphone berhasil mengirim SMS");
    }
    public void kirimSMS(int no_hp1, int no_hp2)
    {
        System.out.println("Handphone berhasil mengirim SMS ke nomor 1 dan 2");
    }
}
